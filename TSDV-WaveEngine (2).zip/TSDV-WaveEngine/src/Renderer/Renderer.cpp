#include "Renderer.h"

#include <cmath>
#include <string>
#include <vector>
#include <utility>
#include <cstddef>
#include <unordered_map>

#include "Mesh/Mesh.h"
#include "VertexData.h"
#include "Plane/Plane.h"
#include "Window/Window.h"
#include "ECS/MaterialID.h"
#include "ECS/Mesh/MeshID.h"
#include "ECS/Camera/Camera.h"
#include "Material/Material.h"
#include "Material/Color/Color.h"
#include "FileReader/FileReader.h"
#include "BoundingBox/BoundingBox.h"
#include "Material/MaterialManager.h"
#include "WaveMath/Vector3/Vector3.h"
#include "Material/MaterialFactory.h"
#include "ECS/WaveObject/WaveObject.h"
#include "ECS/Transform/ECSTransform.h"
#include "WaveMath/WaveMath/WaveMath.h"
#include "WaveMath/Matrix4x4/Matrix4x4.h"
#include "Mesh/MeshManager/MeshManager.h"
#include "TextureImporter/TextureManager.h"
#include "ServiceProvider/ServiceProvider.h"
#include "ECS/CompontRegistry/ComponentRegistry.h"
#include "Material/WaveMaterialBehaviour/WaveMaterialBehaviour.h"

using namespace std;

namespace WaveEngine
{
	DirLight Renderer::dirLight;
	SpotLight Renderer::flashLights[Renderer::Amount_Per_Light];
	PointLight Renderer::pointLight[Renderer::Amount_Per_Light];

	Renderer::Renderer()
	{
	}

	Renderer::~Renderer()
	{
	}

	Window* Renderer::GetWindow()
	{
		return ServiceProvider::Instance().Get<Window>();
	}

	MaterialManager* Renderer::GetMaterialManager()
	{
		return ServiceProvider::Instance().Get<MaterialManager>();
	}

	MeshManager* Renderer::GetMeshManager()
	{
		return ServiceProvider::Instance().Get<MeshManager>();
	}

	TextureManager* Renderer::GetTextureManager()
	{
		return ServiceProvider::Instance().Get<TextureManager>();
	}

	ComponentRegistry* Renderer::GetComponentRegistry()
	{
		return ServiceProvider::Instance().Get<ComponentRegistry>();
	}

	MaterialFactory* Renderer::GetMaterialFactory()
	{
		return ServiceProvider::Instance().Get<MaterialFactory>();
	}

	FileReader* Renderer::GetFileReader()
	{
		return ServiceProvider::Instance().Get<FileReader>();
	}

	void Renderer::Init()
	{
		glViewport(0, 0, GetWindow()->GetWidth(), GetWindow()->GetHeight());

		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LESS);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glDisable(GL_CULL_FACE);

		debugMaterialID = *Material::Load("WireFrame", "Shaders/WireFrame/WireFrame.vert", "Shaders/WireFrame/WireFrame.frag");
		infinitePlaneMaterialID = *Material::Load("InfinitePlane", "Shaders/Planes/InfinitePlane.vert", "Shaders/Planes/InfinitePlane.frag");
	}

	const unsigned int Renderer::ReturnWorkingMaterial(const unsigned int& materialIDToTry, const unsigned int& materialIDfallBack)
	{
		return materialIDToTry != WObject::NULL_OBJECT ? materialIDToTry : materialIDfallBack;
	}

	void Renderer::CreateBuffers(
		const VertexData* vertex,
		const int vertexSize,
		const unsigned int* indices,
		const int indicesSize,
		unsigned int& VAO,
		unsigned int& VBO,
		unsigned int& EBO,
		unsigned int& instanceVBO
	) const
	{
		glGenVertexArrays(1, &VAO);
		glGenBuffers(1, &VBO);
		glGenBuffers(1, &EBO);
		glGenBuffers(1, &instanceVBO);

		glBindVertexArray(VAO);

		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, vertexSize * sizeof(VertexData), vertex, GL_STATIC_DRAW);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicesSize * sizeof(unsigned int), indices, GL_DYNAMIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, position));
		glEnableVertexAttribArray(0);

		glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, color));
		glEnableVertexAttribArray(1);

		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, textureCordinates));
		glEnableVertexAttribArray(2);

		glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, normal));
		glEnableVertexAttribArray(3);

		glBindBuffer(GL_ARRAY_BUFFER, instanceVBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(InstanceData), nullptr, GL_DYNAMIC_DRAW);

		for (int i = 0; i < 4; i++)
		{
			glEnableVertexAttribArray(4 + i);
			glVertexAttribPointer(
				4 + i,
				4,
				GL_FLOAT,
				GL_FALSE,
				sizeof(InstanceData),
				(void*)(offsetof(InstanceData, model) + i * sizeof(float) * 4)
			);

			glVertexAttribDivisor(4 + i, 1);
		}

		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glVertexAttribPointer(8, 3, GL_FLOAT, GL_FALSE, sizeof(VertexData), (void*)offsetof(VertexData, tangent));
		glEnableVertexAttribArray(8);

		glBindVertexArray(0);
	}

	void Renderer::UpdateBuffer(const VertexData* vertex, int vertexSize, unsigned int VBO)
	{
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferSubData(GL_ARRAY_BUFFER, 0, vertexSize * sizeof(VertexData), vertex);
	}

	void Renderer::SubmitWireBox(const BoundingBox& box, Color color)
	{
		debugBoxes.push_back({ box, color });
	}

	void Renderer::DrawWireBoxImmediate(const BoundingBox& box, Color color)
	{
		Vector3 min = box.GetMin();
		Vector3 max = box.GetMax();

		std::vector<Vector3> vertices =
		{
			{ min.x, min.y, min.z },
			{ max.x, min.y, min.z },
			{ max.x, min.y, max.z },
			{ min.x, min.y, max.z },
			{ min.x, max.y, min.z },
			{ max.x, max.y, min.z },
			{ max.x, max.y, max.z },
			{ min.x, max.y, max.z }
		};

		const GLuint indices[] = {
			0, 1, 1, 2, 2, 3, 3, 0, // Bottom face
			4, 5, 5, 6, 6, 7, 7, 4, // Top face
			0, 4, 1, 5, 2, 6, 3, 7  // Vertical edges
		};

		GLuint VAO, VBO, EBO;
		glGenVertexArrays(1, &VAO);
		glGenBuffers(1, &VBO);
		glGenBuffers(1, &EBO);

		glBindVertexArray(VAO);

		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vector3), &vertices[0], GL_STATIC_DRAW);

		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
		glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

		glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);

		Material& mat = GetMaterialManager()->GetMaterial(debugMaterialID);
		mat.Bind();

		for (Camera& camera : GetComponentRegistry()->GetComponentStorage<Camera>().GetComponents())
		{
			if (!mat)
			{
				glBindVertexArray(0);
				glDeleteVertexArrays(1, &VAO);
				glDeleteBuffers(1, &VBO);
				glDeleteBuffers(1, &EBO);
				return;
			}

			mat.SetMat4("uView", camera.GetView().Transposed());
			mat.SetMat4("uProj", camera.GetProjection().Transposed());
			mat.SetMat4("uModel", Matrix4x4::Identity());
			mat.SetColor(color);

			glDrawElements(GL_LINES, sizeof(indices) / sizeof(GLuint), GL_UNSIGNED_INT, 0);
		}

		mat.UnBind();

		glBindVertexArray(0);
		glDeleteVertexArrays(1, &VAO);
		glDeleteBuffers(1, &VBO);
		glDeleteBuffers(1, &EBO);
	}

	void Renderer::SubmitPlane(Plane plane, Color color)
	{
		debugPlanes.push_back({ plane, color });
	}

	void Renderer::DrawInfinitePlaneImmediate(Plane plane, Color color, float fadeDistance)
	{
		static const float quadVerts[] = {
			-1.0f, -1.0f,
			 1.0f, -1.0f,
			 1.0f,  1.0f,
			-1.0f, -1.0f,
			 1.0f,  1.0f,
			-1.0f,  1.0f
		};

		GLuint VAO, VBO;
		glGenVertexArrays(1, &VAO);
		glGenBuffers(1, &VBO);

		glBindVertexArray(VAO);

		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferData(GL_ARRAY_BUFFER, sizeof(quadVerts), quadVerts, GL_STATIC_DRAW);

		glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(float), (void*)0);
		glEnableVertexAttribArray(0);

		Camera& camera = GetComponentRegistry()->GetComponentStorage<Camera>().GetFirst();
		Material& mat = GetMaterialManager()->GetMaterial(infinitePlaneMaterialID);

		if (!mat)
		{
			glBindVertexArray(0);
			glDeleteVertexArrays(1, &VAO);
			glDeleteBuffers(1, &VBO);
			return;
		}

		Matrix4x4 view = camera.GetView();
		Matrix4x4 proj = camera.GetProjection();
		Matrix4x4 invViewProj = Matrix4x4::Inversed(proj * view);

		mat.Bind();
		mat.SetMat4("uView", view.Transposed());
		mat.SetMat4("uProj", proj.Transposed());
		mat.SetMat4("uInvViewProj", invViewProj.Transposed());
		mat.SetVec3("uCameraPos", camera.GetTransform().GetPosition());
		mat.SetVec3("uPlaneNormal", plane.GetNormal());
		mat.SetFloat("uPlaneOriginDistance", plane.GetOriginDistance());
		mat.SetFloat("uFadeDistance", fadeDistance);
		mat.SetColor(color);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glDrawArrays(GL_TRIANGLES, 0, 6);

		glDisable(GL_BLEND);
		mat.UnBind();

		glBindVertexArray(0);
		glDeleteVertexArrays(1, &VAO);
		glDeleteBuffers(1, &VBO);
	}

	void Renderer::DeleteBuffers(unsigned int& VAO, unsigned int& VBO, unsigned int& EBO)
	{
		glDeleteVertexArrays(1, &VAO);
		glDeleteBuffers(1, &VBO);
		glDeleteBuffers(1, &EBO);
	}

	void Renderer::UpdateBuffer(VertexData* vertex, int vertexSize, unsigned& VBO)
	{
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferSubData(GL_ARRAY_BUFFER, 0, vertexSize * sizeof(VertexData), vertex);
	}

	void Renderer::Clear()
	{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		drawCalls = 0;
	}

	unsigned int Renderer::GetDrawCalls() const
	{
		return drawCalls;
	}

	unsigned int Renderer::GetBatchCalls() const
	{
		return batchCalls;
	}

	void Renderer::Submit(const ECSTransform& transform, const MeshID& meshComp, const MeshRenderer& matComp, unsigned int cameraID)
	{
		++batchCalls;

		entityCameras[transform.GetID()].push_back(cameraID);

		RenderData& batch =
			batching[matComp.materialID][meshComp.meshID];

		batch.instances.push_back({ transform.GetID(), transform.GetGlobalModel().Transposed() });
	}

	void Renderer::Flush()
	{
		batchCalls = 0;

		for (unordered_map<unsigned int, unordered_map<unsigned int, RenderData>>::iterator batchingIT = batching.begin(); batchingIT != batching.end(); ++batchingIT)
		{
			if (batchingIT->second.empty())
				continue;

			Material& materialToUse =
				GetMaterialManager()->GetMaterial(batchingIT->first);

			WaveMaterialBehaviour* materialBehaviour = nullptr;
			materialToUse.TryGetBehaviour(materialBehaviour);

			materialToUse.Bind();

			for (Camera& camera : GetComponentRegistry()->GetComponentStorage<Camera>().GetComponents())
			{
				glViewport(camera.viewPortRes.GetCenter().x, camera.viewPortRes.GetCenter().y, camera.viewPortRes.GetSize().x * GetWindow()->GetWidth(), camera.viewPortRes.GetSize().y * GetWindow()->GetHeight());

				ECSTransform& cameraTransform = camera.GetWaveObject().GetTransform();

				Matrix4x4 view = camera.GetView();
				Matrix4x4 proj = camera.GetProjection();

				materialToUse.SetVec4("uColor", materialToUse.GetColor());
				materialToUse.SetMat4("uView", view.Transposed());
				materialToUse.SetMat4("uProj", proj.Transposed());

				materialToUse.SetVec3("dirLight.direction", dirLight.direction);
				materialToUse.SetVec3("dirLight.ambient", dirLight.ambient);
				materialToUse.SetVec3("dirLight.diffuse", dirLight.diffuse);
				materialToUse.SetVec3("dirLight.specular", dirLight.specular);

				for (int i = 0; i < Amount_Per_Light; ++i)
				{
					string base = "pointLights[" + std::to_string(i) + "]";

					materialToUse.SetVec3(base + ".position", pointLight[i].position);

					materialToUse.SetVec3(base + ".ambient", pointLight[i].ambient);
					materialToUse.SetVec3(base + ".diffuse", pointLight[i].diffuse);
					materialToUse.SetVec3(base + ".specular", pointLight[i].specular);

					materialToUse.SetFloat(base + ".constant", pointLight[i].constant);
					materialToUse.SetFloat(base + ".linear", pointLight[i].linear);
					materialToUse.SetFloat(base + ".quadratic", pointLight[i].quadratic);
				}

				materialToUse.SetVec3("viewPos", cameraTransform.position);

				for (int i = 0; i < Amount_Per_Light; ++i)
				{
					string base = "flashlights[" + std::to_string(i) + "]";

					materialToUse.SetVec3(base + ".position", flashLights[i].position);

					materialToUse.SetVec3(base + ".direction", flashLights[i].direction);

					materialToUse.SetVec3(base + ".ambient", flashLights[i].ambient);
					materialToUse.SetVec3(base + ".diffuse", flashLights[i].diffuse);
					materialToUse.SetVec3(base + ".specular", flashLights[i].specular);

					materialToUse.SetFloat(base + ".constant", flashLights[i].constant);
					materialToUse.SetFloat(base + ".linear", flashLights[i].linear);
					materialToUse.SetFloat(base + ".quadratic", flashLights[i].quadratic);

					materialToUse.SetFloat(base + ".cutOff", cos(WaveMath::Deg2Rad(flashLights[i].cutOff)));
					materialToUse.SetFloat(base + ".outerCutOff", cos(WaveMath::Deg2Rad(flashLights[i].outerCutOff)));
				}

				for (unordered_map<unsigned int, RenderData>::iterator meshBatchIT = batchingIT->second.begin(); meshBatchIT != batchingIT->second.end(); ++meshBatchIT)
				{
					RenderData& batch = meshBatchIT->second;

					if (batch.instances.empty())
						continue;

					Mesh& mesh = GetMeshManager()->Get(meshBatchIT->first);

					if (batch.VAO == 0)
					{
						CreateBuffers(
							mesh.GetVertexBuffer(),
							mesh.GetVertexSize(),
							mesh.GetIndexes(),
							mesh.GetIndexesSize(),
							batch.VAO,
							batch.VBO,
							batch.EBO,
							batch.instanceVBO
						);

						batch.instanceCapacity = 0;
					}

					if (mesh.GetDirty())
					{
						UpdateBuffer(mesh.GetVertexBuffer(), mesh.GetVertexSize(), batch.VBO);
						mesh.UnDirt();
					}

					glBindVertexArray(batch.VAO);
					glBindBuffer(GL_ARRAY_BUFFER, batch.instanceVBO);

					if (batch.instances.size() > batch.instanceCapacity)
					{
						batch.instanceCapacity = batch.instances.size();

						glBufferData(GL_ARRAY_BUFFER,
							batch.instanceCapacity * sizeof(InstanceData),
							nullptr,
							GL_DYNAMIC_DRAW);
					}

					glBufferSubData(GL_ARRAY_BUFFER,
						0,
						batch.instances.size() * sizeof(InstanceData),
						batch.instances.data());

					glDrawElementsInstanced(
						GL_TRIANGLES,
						mesh.GetIndexesSize(),
						GL_UNSIGNED_INT,
						0,
						batch.instances.size()
					);

					++drawCalls;

					batch.instances.clear();
				}
			}

			materialToUse.UnBind();
		}

		entityCameras.clear();
	}

	void Renderer::FlushDebug()
	{
		//glDisable(GL_DEPTH_TEST);

		for (std::pair<BoundingBox, Color>& pair : debugBoxes)
			DrawWireBoxImmediate(pair.first, pair.second);

		for (std::pair<Plane, Color>& pair : debugPlanes)
			DrawInfinitePlaneImmediate(pair.first, pair.second);

		//glEnable(GL_DEPTH_TEST);
		debugBoxes.clear();
		debugPlanes.clear();
	}

	void Renderer::Dispose()
	{
		for (unordered_map<unsigned int, unordered_map<unsigned int, RenderData>>::iterator batchingIT = batching.begin(); batchingIT != batching.end(); ++batchingIT)
			for (unordered_map<unsigned int, RenderData>::iterator meshBatching = batchingIT->second.begin(); meshBatching != batchingIT->second.end(); ++meshBatching)
				DeleteBuffers(meshBatching->second.VAO, meshBatching->second.VBO, meshBatching->second.EBO);
	}
}