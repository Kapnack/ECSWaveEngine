#pragma once

#include "ServiceProvider/Service.h"

#include <utility>
#include <glm/fwd.hpp>
#include <vector>
#include <list>
#include <unordered_map>

#include "Window/Window.h"
#include "VertexData.h"
#include "ECS/CompontRegistry/ComponentRegistry.h"
#include "Mesh/MeshManager/MeshManager.h"
#include "Material/MaterialManager.h"
#include "ECS/MaterialID.h"
#include "ECS/Mesh/MeshID.h"
#include "ECS/Transform/ECSTransform.h"
#include "WaveMath/Vector3/Vector3.h"
#include "BoundingBox/BoundingBox.h"
#include "Material/Material.h"
#include "FileReader/FileReader.h"
#include "Material/MaterialFactory.h"
#include "Material/Color/Color.h"
#include "TextureImporter/TextureManager.h"
#include <Plane/Plane.h>
#include <WaveMath/Matrix4x4/Matrix4x4.h>

using namespace std;

namespace WaveEngine
{
	struct DirLight
	{
		Vector3 direction = { -0.41f, -0.82f, -0.39f };

		Vector3 ambient = { 0.06f, 0.06f, 0.06f };
		Vector3 diffuse = { 0.45f, 0.42f, 0.40f };
		Vector3 specular = { 0.50f, 0.50f, 0.50f };
	};

	struct PointLight
	{
		Vector3 position = { 3.8f, 1.6f, -2.9f };

		Vector3 ambient = { 0.04f, 0.04f, 0.04f };
		Vector3 diffuse = { 0.90f, 0.70f, 0.60f };
		Vector3 specular = { 1.00f, 1.00f, 1.00f };

		float constant = 1.0f;
		float linear = 0.07f;
		float quadratic = 0.017f;
	};

	struct SpotLight
	{
		Vector3 position = { 96, 64.0f, 0.0f };
		Vector3 direction = Vector3::Down();

		Vector3 ambient = Vector3::One() * 0.1f;
		Vector3 diffuse = Vector3::One();
		Vector3 specular = Vector3::One();

		float constant = 1.0f;
		float linear = 0.00032f;
		float quadratic = 0.00032f;

		float cutOff = 12.5f;
		float outerCutOff = 15.5f;
	};

	class Engine;

	class Renderer final : public Service
	{
	private:

		struct InstanceData
		{
			unsigned int entityID;
			Matrix4x4 model;
		};

		struct RenderData
		{
			unsigned int VAO = 0;
			unsigned int VBO = 0;
			unsigned int EBO = 0;

			unsigned int instanceVBO = 0;

			vector<InstanceData> instances;

			int instanceCapacity = 0;

			unsigned int indexOffset = 0;
		};

		friend class Engine;

		unordered_map<unsigned int, unordered_map<unsigned int, RenderData>> batching;

		unordered_map<unsigned int, list<unsigned int>> entityCameras;

		vector<pair<BoundingBox, Color>> debugBoxes;
		vector<pair<Plane, Color>> debugPlanes;

		unsigned int drawCalls = 0;
		unsigned int batchCalls = 0;

		unsigned int debugMaterialID = WObject::NULL_OBJECT;
		unsigned int infinitePlaneMaterialID = WObject::NULL_OBJECT;

		void Init();
		void Dispose();

		const unsigned int ReturnWorkingMaterial(const unsigned int& materialIDToTry, const unsigned int& materialIDfallBack);

		Window* GetWindow();

		MaterialManager* GetMaterialManager();

		MeshManager* GetMeshManager();

		TextureManager* GetTextureManager();

		void UpdateBuffer(VertexData* vertex, int vertexSize, unsigned& VBO);

		ComponentRegistry* GetComponentRegistry();

		MaterialFactory* GetMaterialFactory();

		FileReader* GetFileReader();

	public:

		static const int Amount_Per_Light = 2;

		static DirLight dirLight;
		static PointLight pointLight[Amount_Per_Light];
		static SpotLight flashLights[Amount_Per_Light];

		Renderer();
		~Renderer();

		void CreateBuffers(
			const VertexData* vertex,
			const int vertexSize,
			const unsigned int* indices,
			const int indicesSize,
			unsigned int& VAO,
			unsigned int& VBO,
			unsigned int& EBO,
			unsigned int& instanceVBO
		) const;

		void DeleteBuffers(unsigned int& VAO, unsigned int& VBO, unsigned int& EBO);

		void UpdateBuffer(const VertexData* vertex, int vertexSize, unsigned int VBO);

		void SubmitWireBox(const BoundingBox& box, Color color = Color::Red());
		void DrawWireBoxImmediate(const BoundingBox& box, Color color);

		void SubmitPlane(Plane plane, Color color = Color(1.0f, 0.0f, 0.0f, 0.1f));
		void DrawInfinitePlaneImmediate(Plane plane, Color color, float fadeDistance = 0.0f);

		void Clear();

		unsigned int GetDrawCalls() const;
		unsigned int GetBatchCalls() const;

		void Submit(const ECSTransform& transform, const MeshID& meshComp, const MeshRenderer& matComp, unsigned int cameraID);
		void Flush();
		void FlushDebug();
	};
}

