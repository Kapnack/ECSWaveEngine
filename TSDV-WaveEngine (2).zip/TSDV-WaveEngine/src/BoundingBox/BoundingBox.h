#pragma once

#include "Export.h"
#include "WaveMath/Vector3/Vector3.h"
#include "WaveMath/Matrix4x4/Matrix4x4.h"

namespace WaveEngine
{
	struct WAVEEXPORT BoundingBox final
	{
	private:

		Vector3 min = Vector3::Zero();
		Vector3 max = Vector3::Zero();

	public:

		BoundingBox();
		BoundingBox(Vector3 center, Vector3 size);
		~BoundingBox();

		void Encapsulate(const BoundingBox& boundingBox);
		void Encapsulate(Vector3 point);

		void SetMinMax(Vector3 vectorA, Vector3 vectorB);

		void SetMin(Vector3 min);
		void SetMax(Vector3 max);
		void SetSize(Vector3 size);
		void SetCenter(Vector3 center);

		bool IsEmpty() const;

		void Reset();

		Vector3 GetCenter() const;
		Vector3 GetSize() const;
		Vector3 GetExtents() const;
		Vector3 GetMin() const;
		Vector3 GetMax() const;

		bool Intersects(BoundingBox other) const;

		static Matrix4x4 MakeMatrix(BoundingBox boundingBox);
	};
}