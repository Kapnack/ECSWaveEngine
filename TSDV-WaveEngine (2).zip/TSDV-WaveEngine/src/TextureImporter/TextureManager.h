#pragma once

#include "ServiceProvider/Service.h"

#include <set>
#include <map>
#include <string>
#include <string_view>

#include "Export.h"
#include "TextureImporter/Texture.h"

namespace WaveEngine
{
	class TextureImporter;
	class Engine;
	class EntitiesImGui;
	class TexturesImGui;
	class TileMap;
	class Renderer;

	using namespace std;

	class WAVEEXPORT TextureManager final : public Service
	{
	private:

		map<unsigned int, Texture*> textures;
		map<string, unsigned int> indexByname;
		set<unsigned int> texturesToDestroy;

		TextureManager();
		~TextureManager();

		void Save(Texture*& texture);

		void Update();

		map<unsigned int, Texture*>& GetTextures();

		friend class Engine;
		friend class TextureImporter;
		friend class ServiceProvider;
		friend class EntitiesImGui;
		friend class TexturesImGui;
		friend class TileMap;
		friend class Renderer;

	public:

		void Destroy(Texture& texture);
		void Destroy(unsigned int ID);
		void DestroyImmediate(Texture& texture);
		void DestroyImmediate(unsigned int ID);

		Texture* GetTexture(const unsigned int& ID) const;
		Texture* TryGetTexture(const unsigned int& ID) const;
	};
}