#include "TextureImporter.h"

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

#include <GL/glew.h>
#include <iostream>
#include <filesystem>

#include "Texture.h"
#include "TextureManager.h"
#include "ServiceProvider/ServiceProvider.h"

namespace WaveEngine
{
	TextureImporter::TextureImporter() : Service()
	{
	}

	TextureImporter::~TextureImporter()
	{
	}

	TextureManager* TextureImporter::GetTextureManager()
	{
		return ServiceProvider::Instance().Get<TextureManager>();
	}

	Texture* TextureImporter::LoadTexture(const string_view filePath, bool useAbsolutePath, const char* overrideName)
	{
		int width = 0;
		int height = 0;
		int nrChannels = 0;

		stbi_set_flip_vertically_on_load(true);

		const char* completePath = filePath.data();

		unsigned char* data = stbi_load(completePath, &width, &height, &nrChannels, 0);

		GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;

		if (!data)
		{
			std::cout << "Failed to load texture: " << filePath << std::endl;
			return 0;
		}

		unsigned int textureGPUID = 0;

		glGenTextures(1, &textureGPUID);
		glBindTexture(GL_TEXTURE_2D, textureGPUID);

		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glBindTexture(GL_TEXTURE_2D, 0);

		Texture* newTexture = new Texture(textureGPUID, width, height);

		newTexture->SetID(++currentTextureID);

		std::filesystem::path path = filePath;

		newTexture->name = overrideName ? overrideName : path.filename().string();

		GetTextureManager()->Save(newTexture);

		stbi_image_free(data);

		std::cout << "Loaded texture: " << filePath << " (" << width << "x" << height << ")" << std::endl;

		return newTexture;
	}

	Texture* TextureImporter::LoadTextureFromMemory(const unsigned char* buffer, int size)
	{
		int width;
		int height;
		int nrChannels;

		stbi_set_flip_vertically_on_load(true);

		unsigned char* data =
			stbi_load_from_memory(buffer, size, &width, &height, &nrChannels, 0);

		if (!data)
		{
			std::cout << "Failed to load embedded texture\n";
			return 0;
		}

		GLenum format = (nrChannels == 4) ? GL_RGBA : GL_RGB;

		unsigned int textureGPUID = 0;

		glGenTextures(1, &textureGPUID);
		glBindTexture(GL_TEXTURE_2D, textureGPUID);

		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0, format, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);

		glBindTexture(GL_TEXTURE_2D, 0);

		Texture* newTexture = new Texture(textureGPUID, width, height);

		newTexture->SetID(++currentTextureID);

		newTexture->name = "embedded_" + std::to_string(currentTextureID);

		GetTextureManager()->Save(newTexture);

		stbi_image_free(data);

		std::cout << "Loaded embedded texture (" << width << "x" << height << ")" << std::endl;

		return newTexture;
	}

	Texture* TextureImporter::LoadTextureFromPixels(const unsigned char* buffer, const unsigned int& width, const unsigned int& height)
	{
		unsigned int textureGPUID = 0;

		glGenTextures(1, &textureGPUID);
		glBindTexture(GL_TEXTURE_2D, textureGPUID);

		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// aiTexel is BGRA, no stbi involved — upload raw pixels directly
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0,
			GL_BGRA, GL_UNSIGNED_BYTE, buffer);
		glGenerateMipmap(GL_TEXTURE_2D);

		glBindTexture(GL_TEXTURE_2D, 0);

		Texture* newTexture = new Texture(textureGPUID, width, height);

		newTexture->SetID(++currentTextureID);

		newTexture->name = "embedded_pixels_" + std::to_string(currentTextureID);

		GetTextureManager()->Save(newTexture);

		std::cout << "Loaded embedded raw texture (" << width << "x" << height << ")" << std::endl;

		return newTexture;
	}
}