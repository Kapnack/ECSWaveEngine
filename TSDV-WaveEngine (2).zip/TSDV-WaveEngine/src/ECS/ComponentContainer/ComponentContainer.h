#pragma once

#include <vector>
#include <type_traits>

#include "ECS/Component/Component.h"
#include "ECS/Component/TypeComponent.h"

using namespace std;

namespace WaveEngine
{
	class WaveBehaviour;

	class IStorage
	{
	public:

		IStorage()
		{
		}

		virtual ~IStorage()
		{
		}

		virtual void Add(unsigned int entitiy) = 0;

		virtual bool Has(unsigned int entity) const = 0;

		virtual void Remove(unsigned int entity) = 0;

		virtual Component& GetBase(unsigned int entity) = 0;
		virtual vector<Component*> GetBaseComponents() = 0;

		virtual WaveBehaviour* GetAsWaveBehaviour(unsigned int entity) { return nullptr; }
	};

	template <TypeComponent T>
	class ComponentContainer : public IStorage
	{
	private:

		vector<T> components;
		vector<unsigned int> entities;
		vector<unsigned int> componentByEntity;

	public:

		void Add(unsigned int entity) override
		{
			if (entity >= componentByEntity.size())
			{
				size_t oldSize = componentByEntity.size();
				componentByEntity.resize(entity + 1);
				for (size_t i = oldSize; i < componentByEntity.size(); ++i)
					componentByEntity[i] = -1;
			}

			int index = components.size();

			components.emplace_back();
			entities.push_back(entity);

			componentByEntity[entity] = index;

			T& component = Get(entity);

			component.SetID(entity);
			component.SetActive(true);
			component.Init();
			component.LateInit();
		}

		bool Has(unsigned int entity) const override
		{
			if (entity >= componentByEntity.size())
				return false;

			return componentByEntity[entity] != -1;
		}

		void Remove(unsigned int entity) override
		{
			if (!Has(entity))
				return;

			Get(entity).SetActive(false);
			Get(entity).Dispose();

			int index = componentByEntity[entity];
			int lastIndex = components.size() - 1;

			if (index != lastIndex)
			{
				components[index] = components[lastIndex];
				entities[index] = entities[lastIndex];

				componentByEntity[entities[index]] = index;
			}

			components.pop_back();
			entities.pop_back();

			componentByEntity[entity] = -1;
		}

		T& Get(unsigned int entity)
		{
			return components.at(componentByEntity.at(entity));
		}

		Component& GetBase(unsigned int entity) override
		{
			return *static_cast<Component*>(&Get(entity));
		}

		T& GetFirst()
		{
			typename std::vector<T>::iterator it = components.begin();
			return *it;
		}

		T* TryGet(unsigned int entity)
		{
			if (entity >= componentByEntity.size())
				return nullptr;

			const unsigned int index = componentByEntity[entity];

			if (index == -1)
				return nullptr;

			return &components[index];
		}

		bool TryGet(unsigned int entity, T*& component)
		{
			component = TryGet(entity);
			return component != nullptr;
		}

		vector<T>& GetComponents()
		{
			return components;
		}

		vector<Component*> GetBaseComponents()
		{
			return vector<Component*>(components.begin(), components.end());
		}

		const vector<unsigned int>& GetEntities() const
		{
			return entities;
		}

		WaveBehaviour* GetAsWaveBehaviour(unsigned int entity) override
		{
			if constexpr (std::is_base_of_v<WaveBehaviour, T>)
			{
				if (Has(entity))
					return &Get(entity);
			}

			return nullptr;
		}

		T& operator[](unsigned int entityID)
		{
			return Get(entityID);
		}
	};
}