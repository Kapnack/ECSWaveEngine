#include "BinarySpacePartition.h"
#include "ServiceProvider/Service.h"

#include <vector>
#include <algorithm>

#include "Plane/Plane.h"
#include "Renderer/Renderer.h"
#include "WaveMath/Vector3/Vector3.h"
#include "ECS/WaveObject/WaveObject.h"
#include "WaveMath/WaveMath/WaveMath.h"
#include "ECS/Transform/ECSTransform.h"
#include "ServiceProvider/ServiceProvider.h"
#include "ECS/WaveObject/WaveObjectRegistry.h"
#include "ECS/CompontRegistry/ComponentRegistry.h"
#include "ECS/ComponentContainer/ComponentContainer.h"

namespace WaveEngine
{
	ComponentContainer<ECSTransform>& BinarySpacePartition::GetTransformContainer() const
	{
		return ServiceProvider::Instance().Get<ComponentRegistry>()->GetComponentStorage<ECSTransform>();
	}

	WaveObjectRegistry* BinarySpacePartition::GetWaveObjectRegistry() const
	{
		return ServiceProvider::Instance().Get<WaveObjectRegistry>();
	}

	Renderer* BinarySpacePartition::GetRenderer() const
	{
		return ServiceProvider::Instance().Get<Renderer>();
	}

	BinarySpacePartition::BinarySpacePartition() : Service()
	{
	}

	BinarySpacePartition& BinarySpacePartition::Get()
	{
		return *ServiceProvider::Instance().Get<BinarySpacePartition>();
	}

	bool BinarySpacePartition::ObjectsShareSpace(Vector3 vectorA, Vector3 vectorB, Vector3 vectorBextends)
	{
		for (const Plane& plane : planes)
		{
			const int signOfA = WaveMath::Sign(plane.SignedDistance(vectorA));

			if (signOfA == 0)
				continue;

			const float distB = plane.SignedDistance(vectorB);

			const float radius = Vector3::Dot(plane.GetNormal(), vectorBextends);

			if (signOfA > 0)
			{
				if ((distB + radius) < 0.0f)
					return false;
			}
			else
			{
				if ((distB - radius) > 0.0f)
					return false;
			}
		}

		return true;
	}

	void BinarySpacePartition::AddPlane(Plane newPlane)
	{
		for (const Plane& plane : planes)
			if (newPlane == plane)
				return;

		planes.push_back(newPlane);
	}

	void BinarySpacePartition::TurnObjectIntoPlane(const WaveObject& waveObject)
	{
		objectsToMadePlane.push_back(waveObject.GetID());
	}

	void BinarySpacePartition::TurnObjectIntoPlane(unsigned int waveObjectID)
	{
		objectsToMadePlane.push_back(waveObjectID);
	}

	void BinarySpacePartition::RemovePlane(Plane plane)
	{
		planes.erase(remove_if(planes.begin(), planes.end(), [&](Plane it) { return it == plane; }), planes.end());
	}

	const vector<Plane>& BinarySpacePartition::GetPlanes()
	{
		return planes;
	}

	void BinarySpacePartition::Update()
	{
		for (unsigned int waveObjectID : objectsToMadePlane)
		{
			ECSTransform& waveObject = GetTransformContainer().Get(waveObjectID);

			planes.push_back(Plane(waveObject.GetForward(), waveObject.GetPosition()));
		}

		objectsToMadePlane.clear();

		for (const Plane& plane : planes)
			GetRenderer()->SubmitPlane(plane);
	}
}
